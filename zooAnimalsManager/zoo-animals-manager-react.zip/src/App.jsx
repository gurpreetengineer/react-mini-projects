import React from 'react';
import './App.css';
import AnimalMainPage from './components/uiTemplate';

function App() {
  return (
    <div className="App">
      <AnimalMainPage />
    </div>
  );
}

export default App;
